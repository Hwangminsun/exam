$(function(){

  // top 아이콘 부드럽게 따라오기 
const top = parseInt($("#go_top").css("top"));
$(window).on("scroll", function () {

    const dis = $(window).scrollTop();
    $("#go_top").stop().animate({
        top: dis + top + "px"
    }, 1100);
});

  // Animate the scroll to top
  $('#go_top').click(function(event) {
    event.preventDefault();
    
    $('html, body').animate({scrollTop: 0}, 500);
  });


// top_menu scroll
  $('.top_menu li:first-child a').click(function(e) {
    $('html, body').animate({scrollTop: 5}, 700);
    e.preventDefault();
  });

  $('.top_menu li:nth-child(2) a').click(function(e) {
    $('html, body').animate({scrollTop: 2420}, 700);
    e.preventDefault();
  });

  $('.top_menu li:nth-child(3) a').click(function(e) {
    $('html, body').animate({scrollTop: 3420}, 500);
    e.preventDefault();
  });
    

// left tab_menu scroll (subject / 큰 제목)

$('.left > li:first-child a').click(function(e) {
  $('html, body').animate({scrollTop: 5}, 700);
  e.preventDefault();
});

$('.left > li:nth-child(2) a').click(function(e) {
  $('html, body').animate({scrollTop: 1820}, 700);
  e.preventDefault();
});

$('.left > li:nth-child(3) a').click(function(e) {
  $('html, body').animate({scrollTop: 2375}, 700);
  e.preventDefault();
});

$('.left > li:nth-child(4) a').click(function(e) {
  $('html, body').animate({scrollTop: 3420}, 500);
  e.preventDefault();
});

// tab li_sub scroll



// .background 요소의 좌표 확인

const top1 = $('.background').position().top; // num == 0 일경우, top: 6
const left1 = $('.background').position().left; // num == 0 일경우, left: 687.25

console.log(top1);
console.log(left1);

const top2 = $('.top_menu li').eq(1).position().top; // num == 1 , top: 0
const left2 = $('.top_menu li').eq(1).position().left; // num == 1 , left: 886.44140625

console.log(top2);
console.log(left2);

const top3 = $('.top_menu li').eq(2).position().top; // num == 2 , top: 0
const left3 = $('.top_menu li').eq(2).position().left; // num == 2 , left: 1057.34765625 

console.log(top3);
console.log(left3);

const pro1 = $('#project3').position().top;
console.log(pro1);

const pro2 = $('#project4').position().top;
console.log(pro2);

  // 헤더메뉴 누르면 선택된 tab 메뉴 글자 색 변경

$('.top_menu li').click(function(){

  const num = $(this).index();

  $('.subject').css('color','#666'); // tab 메뉴 글자 색 원래대로
 
  if (num == 0) {
    $('.project').css('color','#7ecd87'); // 선택한 tab 메뉴
    $('.top_menu li').children('a').css('color','#666'); // 헤더 메뉴
    $(this).children('a').css('color','#7ecd87'); // 선택한 헤더 메뉴

  } else if (num == 1) {
    
    $('.Github').css('color','#7ecd87'); // 선택된 tab 메뉴 색 변경
    $('.top_menu li').children('a').css('color','#666'); // 헤더 메뉴 색 모두 원래대로
    $(this).children('a').css('color','#7ecd87'); // 선택된 헤더 메뉴 색 변경
    
  } else {
   
    $('.About').css('color','#7ecd87'); //  , #7ecd87
    $('.top_menu li').children('a').css('color','#666');
    $(this).children('a').css('color','#7ecd87');
   
  }

});

});