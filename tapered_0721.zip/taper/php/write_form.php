<? 
	session_start(); 

	$table = "free";

	include "dbconn.php";

$num=$_GET['num'];
$page=$_GET['page'];
$mode=$_GET['modify'];
$id=$_POST['id'];

	if (isset($_GET["mode"]))
	$mode = $_GET["mode"];
  else
	$mode = "";


	
	if ($mode=="modify")
	{
		$sql = "select * from $table where num=$num";
		$result = mysqli_query( $connect,$sql);
		$row = mysqli_fetch_array($result);  

		if ($result){

			while($row = mysqli_fetch_array($result)){     
	
		$item_subject     = $row['subject'];
		$item_content     = $row['content'];		
	}

}
}
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>TAPERED COFFEE</title>
		<link rel="stylesheet" href="../css/reset.css">
		<link rel="stylesheet" href="css/list.css">
		<link rel="stylesheet" href="css/greet.css">
		<script src="https://kit.fontawesome.com/dbb7afa741.js" crossorigin="anonymous"></script>
  		<script src="../js/jquery-1.11.2.min.js"></script>
		<script src="../js/menu.js"></script>
  		<script src="../js/bottomnav.js"></script>

<script>
  function check_input()
   {
      if (!document.board_form.subject.value)
      {
          alert("제목을 입력하세요1");    
          document.board_form.subject.focus();
          return;
      }

      if (!document.board_form.content.value)
      {
          alert("내용을 입력하세요!");    
          document.board_form.content.focus();
          return;
      }
      document.board_form.submit();
   }
</script>
</head>

<body>
<div id="skip-menu">
    <a href="#menu_wrap">&#187; 메뉴 바로가기</a>
    <a href="#wrap">&#187; 내용 바로가기</a>
  </div>

  <header class="cf">
    <!-- 모바일 햄버거 버튼 -->
    <div id="ham-wrap">
      <div class="hamburger">
         <span></span>  <span></span> <span></span> 
      </div> 
  </div>

    <h1><a href="./index.html"><img src="../img/taper-logo.png" alt="logo"></a></h1>
    <!-- 태블릿, pc 버전 사용 -->
    <ul class="right">
      <? include "top_login2.php"; ?>
        <li><a href="javascript:void(0)"><i class="fa-solid fa-file-pen"></i></li>
        <li><a href="javascript:void(0)">Service</a></li>
        <li><a href="javascript:void(0)"><i class="fa-solid fa-map"></i></a></li>
        <li><a href="javascript:void(0)">Location</a></li>
    </ul>
  </header>

  <!-- 모바일 버전 사용 -->
  <div class="bottomNav" id="usp_sell">
    <ul>
	<? include "top_login1.php"; ?>
    </ul>
  </div>

  <nav id="menu-wrap"> <!--메뉴 전체-->
      <ul class="menu">
        <li><a href="#" onclick="return false;">Menu</a></li>
        <li><a href="#" onclick="return false;">Store</a></li>
        <li><a href="#" onclick="return false;">Brand</a></li>
      </ul>   
  </nav>	

<div id="wrap_1">
  <div id="content_1">
	<div id="col2_1">        
		
			<h2>Contact us</h2>

		<div id="write_form_title">
			<img src="img/write_form_title.gif">
		</div>	
<?
	if($mode=="modify")
	{
?>
		<form  name="board_form" method="post" action="insert1.php?mode=modify&num=<?=$num?>&page=<?=$page?>&table=<?=$table?>" enctype="multipart/form-data"> 
<?
	}
	else
	{
?>
		<form  name="board_form" method="post" action="insert1.php?table=<?=$table?>" enctype="multipart/form-data"> 
<?
	}
?>
		<div id="write_form"> <!-- 게시판 틀 시작 -->
			<!-- <div class="write_line"></div> -->
			<div id="write_row1">
				<div class="col1"> 아이디 </div>
				<div class="col2"><?=$_SESSION['userid']?></div>
			</div>
		
			<!-- <div class="write_line sub_top"></div> -->
			<div id="write_row2">
				<div class="col1">제목</div>
			  	<div class="col2">
					<input type="text" name="subject" value="<?=$item_subject?>" >
				</div>
			</div>

			<!-- <div class="write_line"></div> -->
			<div id="write_row3">
				<div class="col1"> 내용 </div>
			    <div class="col2">
					<textarea rows="15" cols="79" name="content">
						<?=$item_content?>
					</textarea>
				</div>
			</div>
	

		</div> <!-- write_form 끝 -->

		<div id="write_button">
			<a href="#">
				<img src="img/ok.png" onclick="check_input()">
			</a>&nbsp;
			<a href="list.php?table=<?=$table?>&page=<?=$page?>">
				<img src="img/list.png">
			</a>
		</div>
	</form>

	</div> <!-- end of col2 -->
  </div> <!-- end of content -->
</div> <!-- end of wrap -->
<footer>
  <div id="footer"><a href="https://www.instagram.com/taperedcoffee/"
    target="_blank">photo by TAPERED COFFEE INSTAGRAM</a></div>
</footer>
</body>
</html>
