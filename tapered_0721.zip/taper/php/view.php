<? 
	session_start(); 
	include "dbconn.php";
	$table = "free";

  $num=$_GET['num'];
	$id=$_GET['id'];
	$page=$_GET['page'];
	$subject=$_POST['item_subject'];
	$content=$_POST['content'];
	$mode = $_GET['modify'];


	 if (isset($_GET["mode"]))
	 	$mode = $_GET["mode"];
   else
	 	$mode = "";


	$sql = "select * from $table where num=$num";
	$result = mysqli_query( $connect,$sql);
   $row = mysqli_fetch_array($result);       
	
		if ($result){
			while($row = mysqli_fetch_array($result)){

	$item_num     = $row['num'];
	$item_id      = $row['id'];
	$item_name    = $row['name'];
	$item_hit     = $row['hit'];

  $item_date    = $row['regist_day'];
	$item_subject = str_replace(" ", "&nbsp;", $row['subject']);
	$item_content = $row['content'];

		$new_hit = $item_hit + 1;
	$sql = "update $table set hit=$new_hit where num=$num";   // 글 조회수 증가시킴
}
}

	mysqli_query( $connect,$sql);
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>TAPERED COFFEE</title>
		<link rel="stylesheet" href="../css/reset.css">
		<link rel="stylesheet" href="css/list.css">
		<link rel="stylesheet" href="css/greet.css">
		<script src="https://kit.fontawesome.com/dbb7afa741.js" crossorigin="anonymous"></script>
  		<script src="../js/jquery-1.11.2.min.js"></script>
		<script src="../js/menu.js"></script>
  		<script src="../js/bottomnav.js"></script>

<script>
	function check_input()
	{
		if (!document.ripple_form.ripple_content.value)
		{
			alert("내용을 입력하세요!");    
			document.ripple_form.ripple_content.focus();
			return;
		}
		document.ripple_form.submit();
    }

    function del(href) 
    {
        if(confirm("한번 삭제한 자료는 복구할 방법이 없습니다.\n\n정말 삭제하시겠습니까?")) {
                document.location.href = href;
        }
    }
</script>

</head>

<body>
<div id="skip-menu">
    <a href="#menu_wrap">&#187; 메뉴 바로가기</a>
    <a href="#wrap">&#187; 내용 바로가기</a>
  </div>

  <header class="cf">
    <!-- 모바일 햄버거 버튼 -->
    <div id="ham-wrap">
      <div class="hamburger">
         <span></span>  <span></span> <span></span> 
      </div> 
  </div>

    <h1><a href="./index.html"><img src="../img/taper-logo.png" alt="logo"></a></h1>
    <!-- 태블릿, pc 버전 사용 -->
    <ul class="right">
      <? include "top_login2.php"; ?>
        <li><a href="javascript:void(0)"><i class="fa-solid fa-file-pen"></i></li>
        <li><a href="javascript:void(0)">Service</a></li>
        <li><a href="javascript:void(0)"><i class="fa-solid fa-map"></i></a></li>
        <li><a href="javascript:void(0)">Location</a></li>
    </ul>
  </header>

  <!-- 모바일 버전 사용 -->
  <div class="bottomNav" id="usp_sell">
    <ul>
	<? include "top_login1.php"; ?>
    </ul>
  </div>

  <nav id="menu-wrap"> <!--메뉴 전체-->
      <ul class="menu">
        <li><a href="#" onclick="return false;">Menu</a></li>
        <li><a href="#" onclick="return false;">Store</a></li>
        <li><a href="#" onclick="return false;">Brand</a></li>
      </ul>   
  </nav>	

<div id="wrap">
 
  <div id="content">


	<div id="col2">        
		<div id="title">
			<h2>Contact us</h2>
		</div>
		<div id="view_title">
			<div id="view_title1"><?= $item_subject ?></div>
			<div id="view_title2">글쓴이 : <?= $item_id ?> | 조회 : <?= $item_hit ?>  
			                      | <?= $item_date ?> </div>	
		</div>

		<div id="view_content">
			<?= $item_content ?>
		</div>

		<div id="view_button">
			<a href="list.php?table=<?=$table?>&page=<?=$page?>">
				<img src="img/list.png">
			</a>&nbsp;

<? 
//$_SESSION['userid'] 
$userid=$_SESSION['userid'];
$item_id=$_SESSION['userid'];
	
if($userid && ($userid==$item_id))
	{
?>
				<a href="write_form.php?table=<?=$table?>&mode=modify&num=<?=$num?>&page=<?=$page?>">
					<img src="img/modify.png">
				</a>&nbsp;
				<a href="javascript:del('delete2.php?table=<?=$table?>&num=<?=$num?>')">
					<img src="img/delete.png">
				</a>&nbsp;
<?
	}
?>
<? 
	if($userid)
	{
?>
				<a href="write_form.php?table=<?=$table?>"><img src="img/write.png"></a>
<?
	}
?>
		</div>
		<div class="clear"></div>

	</div> <!-- end of col2 -->
  </div> <!-- end of content -->
</div> <!-- end of wrap -->
<footer>
  <div id="footer"><a href="https://www.instagram.com/taperedcoffee/"
    target="_blank">photo by TAPERED COFFEE INSTAGRAM</a></div>
</footer>
</body>
</html>
