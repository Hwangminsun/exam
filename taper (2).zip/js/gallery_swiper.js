$(function(){

    var swiper = new Swiper(".mySwiper", { /* 위쪽 스와이퍼 */
      spaceBetween: 10,
      slidesPerView: 2,
      freeMode: false,
      watchSlidesProgress: true,
    });

    var swiper2 = new Swiper(".mySwiper2", { /* 아래쪽 스와이퍼 */
      spaceBetween: 10,
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
      thumbs: {
        swiper: swiper,
      },
    });

});