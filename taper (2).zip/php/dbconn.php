<?
$connect=mysqli_connect( "localhost","icelatte","min2357**") or
  die("SQL server에 연결할 수 없습니다."); // 접속이 안되면 이 문장이 나옴
  mysqli_select_db($connect,"icelatte");


?>